$(function(){
    document.getElementById('btn').addEventListener('click', function () {
        alert('This is a javascript popup');
    });
});